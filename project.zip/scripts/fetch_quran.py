"""Downloads the Uthmani Quran text (Tanzil Project text, served by alquran.cloud)
and writes app/src/main/assets/quran.json. The build FAILS if the data is incomplete."""
import json, os, sys, urllib.request

URL = "https://api.alquran.cloud/v1/quran/quran-uthmani"
req = urllib.request.Request(URL, headers={"User-Agent": "tilawa-build"})
with urllib.request.urlopen(req, timeout=180) as r:
    payload = json.load(r)

surahs = payload["data"]["surahs"]
if len(surahs) != 114:
    sys.exit("ERROR: expected 114 surahs, got %d" % len(surahs))
total = sum(len(s["ayahs"]) for s in surahs)
if total != 6236:
    sys.exit("ERROR: expected 6236 ayahs, got %d" % total)

bism = surahs[0]["ayahs"][0]["text"]
stripped = 0
out = []
for s in surahs:
    ayahs = []
    for a in s["ayahs"]:
        t = a["text"]
        if s["number"] not in (1, 9) and a["numberInSurah"] == 1 and t.startswith(bism):
            t = t[len(bism):].strip()
            stripped += 1
        if not t.strip():
            sys.exit("ERROR: empty ayah in surah %d" % s["number"])
        ayahs.append([t, a["juz"], a["page"], a.get("hizbQuarter", 0)])
    out.append({"n": s["number"], "name": s["name"], "en": s["englishName"],
                "type": s["revelationType"], "ayahs": ayahs})

os.makedirs("app/src/main/assets", exist_ok=True)
with open("app/src/main/assets/quran.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
print("OK: 114 surahs, %d ayahs, bismillah prefix removed from %d surahs" % (total, stripped))

# Audio: verify reciters (never fails the build; app shows a message if none are reachable)
import subprocess
subprocess.run([sys.executable, "scripts/check_reciters.py"], check=False)

subprocess.run([sys.executable, "scripts/fetch_adhkar.py"], check=False)
