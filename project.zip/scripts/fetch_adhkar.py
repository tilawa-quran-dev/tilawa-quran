"""Downloads Hisn al-Muslim adhkar (text + repeat count) from rn0x/Adhkar-json. Never fails the build."""
import json, os, urllib.request

URL = "https://github.com/rn0x/Adhkar-json/raw/main/adhkar.json"

def to_int(v):
    try:
        return max(1, int(v))
    except Exception:
        return 1

try:
    req = urllib.request.Request(URL, headers={"User-Agent": "tilawa-build"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.load(r)
    cats = []
    for c in data:
        items = []
        for z in c.get("array", []):
            t = (z.get("text") or "").strip()
            if t:
                items.append({"text": t, "count": to_int(z.get("count"))})
        name = (c.get("category") or "").strip()
        if items and name:
            cats.append({"name": name, "items": items})
    assert len(cats) >= 50, "too few categories: %d" % len(cats)
    assert any("الصباح والمساء" in c["name"] for c in cats), "morning/evening category missing"
    os.makedirs("app/src/main/assets", exist_ok=True)
    with open("app/src/main/assets/adhkar.json", "w", encoding="utf-8") as f:
        json.dump(cats, f, ensure_ascii=False, separators=(",", ":"))
    print("OK: %d adhkar categories, %d items" % (len(cats), sum(len(c["items"]) for c in cats)))
except Exception as e:
    print("WARNING: adhkar not available in this build:", e)
