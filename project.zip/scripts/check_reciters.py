"""Keeps only the reciters whose audio really exists on everyayah.com (checked at build time)."""
import json, os, urllib.request

CANDIDATES = [
    ("مشاري العفاسي", "Alafasy_128kbps"),
    ("عبد الباسط عبد الصمد (مرتل)", "Abdul_Basit_Murattal_192kbps"),
    ("محمود خليل الحصري", "Husary_128kbps"),
    ("محمد صديق المنشاوي (مرتل)", "Minshawy_Murattal_128kbps"),
    ("عبد الرحمن السديس", "Abdurrahmaan_As-Sudais_192kbps"),
    ("ماهر المعيقلي", "Maher_AlMuaiqly_128kbps"),
    ("سعود الشريم", "Saood_ash-Shuraym_128kbps"),
    ("علي الحذيفي", "Hudhaify_128kbps"),
    ("سعد الغامدي", "Ghamadi_40kbps"),
    ("أبو بكر الشاطري", "Abu_Bakr_Ash-Shaatree_128kbps"),
    ("ياسر الدوسري", "Yasser_Ad-Dussary_128kbps"),
    ("ناصر القطامي", "Nasser_Alqatami_128kbps"),
    ("محمد أيوب", "Muhammad_Ayyoub_128kbps"),
]
TESTS = ["001001.mp3", "114006.mp3"]

def url_ok(url):
    req = urllib.request.Request(url, headers={"User-Agent": "tilawa-build", "Range": "bytes=0-0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status in (200, 206)
    except Exception:
        return False

def ok(folder):
    for t in TESTS:
        url = "https://everyayah.com/data/%s/%s" % (folder, t)
        req = urllib.request.Request(url, headers={"User-Agent": "tilawa-build", "Range": "bytes=0-0"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                if r.status not in (200, 206):
                    return False
        except Exception:
            return False
    return True

good = []
for name, folder in CANDIDATES:
    if ok(folder):
        good.append({"name": name, "folder": folder})
        print("OK     ", folder)
    else:
        print("MISSING", folder)

# Muhammad Al-Faqih: whole-surah files on archive.org (only the surahs that really exist are kept)
FAQIH_BASE = "https://archive.org/download/002_20231230/"
avail, misses = [], 0
for n in range(1, 115):
    if url_ok(FAQIH_BASE + "%03d.mp3" % n):
        avail.append(n)
        misses = 0
    else:
        misses += 1
        if not avail and misses >= 8:
            break
if avail:
    good.append({"name": "محمد الفقيه (سور كاملة)", "folder": "Faqih_archive", "base": FAQIH_BASE, "surahs": avail})
print("Al-Faqih surahs available: %s" % avail)

os.makedirs("app/src/main/assets", exist_ok=True)
with open("app/src/main/assets/reciters.json", "w", encoding="utf-8") as f:
    json.dump(good, f, ensure_ascii=False)
print("reciters available: %d" % len(good))
