"""Keeps only the reciters whose audio really exists on everyayah.com (checked at build time)."""
import json, os, urllib.request

CANDIDATES = [
    ("مشاري العفاسي", "Alafasy_128kbps"),
    ("عبد الباسط عبد الصمد (مرتل)", "Abdul_Basit_Murattal_192kbps"),
    ("محمود خليل الحصري", "Husary_128kbps"),
    ("محمد صديق المنشاوي (مرتل)", "Minshawy_Murattal_128kbps"),
    ("عبد الرحمن السديس", "Abdurrahmaan_As-Sudais_192kbps"),
    ("ماهر المعيقلي", "Maher_AlMuaiqly_128kbps"),
    ("سعود الشريم", "Saood_ash-Shuraym_128kbps"),
    ("علي الحذيفي", "Hudhaify_128kbps"),
    ("سعد الغامدي", "Ghamadi_40kbps"),
    ("أبو بكر الشاطري", "Abu_Bakr_Ash-Shaatree_128kbps"),
    ("ياسر الدوسري", "Yasser_Ad-Dussary_128kbps"),
    ("ناصر القطامي", "Nasser_Alqatami_128kbps"),
    ("محمد أيوب", "Muhammad_Ayyoub_128kbps"),
]
TESTS = ["001001.mp3", "114006.mp3"]

def ok(folder):
    for t in TESTS:
        url = "https://everyayah.com/data/%s/%s" % (folder, t)
        req = urllib.request.Request(url, headers={"User-Agent": "tilawa-build", "Range": "bytes=0-0"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                if r.status not in (200, 206):
                    return False
        except Exception:
            return False
    return True

good = []
for name, folder in CANDIDATES:
    if ok(folder):
        good.append({"name": name, "folder": folder})
        print("OK     ", folder)
    else:
        print("MISSING", folder)

os.makedirs("app/src/main/assets", exist_ok=True)
with open("app/src/main/assets/reciters.json", "w", encoding="utf-8") as f:
    json.dump(good, f, ensure_ascii=False)
print("reciters available: %d" % len(good))
