# تلاوة (Tilawa) — Quran app for Android

Kotlin + Jetpack Compose. Offline Quran reader with search, bookmarks and last-position memory.

## Data & licenses
- Quran text: Tanzil Project (https://tanzil.net) Uthmani text, unmodified, downloaded at build time
  by `scripts/fetch_quran.py` (served by alquran.cloud). Tanzil's terms: the text must not be altered and
  the source must be credited. See https://tanzil.net/docs/text_license
- Font: Amiri Quran (SIL Open Font License 1.1).
- Libraries: AndroidX / Jetpack Compose / Kotlin (Apache License 2.0). No ads, no trackers, no permissions.

## Build
GitHub Actions (`.github/workflows/build.yml`) builds a debug APK and publishes it as a Release.
