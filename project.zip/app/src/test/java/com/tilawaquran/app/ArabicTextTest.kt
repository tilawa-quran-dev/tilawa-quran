package com.tilawaquran.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ArabicTextTest {
    @Test
    fun removesDiacriticsTatweelAndDaggerAlef() {
        // رَحْمَـٰن  ->  رحمن
        val input = "\u0631\u064E\u062D\u0652\u0645\u064E\u0640\u0670\u0646"
        assertEquals("\u0631\u062D\u0645\u0646", ArabicText.normalize(input))
    }

    @Test
    fun unifiesAlefVariants() {
        assertEquals("\u0627\u0627\u0627\u0627", ArabicText.normalize("\u0623\u0625\u0622\u0671"))
    }

    @Test
    fun digitsRoundTrip() {
        assertEquals("\u0662\u0665\u0665", ArabicText.toArabicDigits(255))
        assertEquals("255", ArabicText.toLatinDigits("\u0662\u0665\u0665"))
    }
}
