package com.tilawaquran.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ArabicTextTest {
    @Test
    fun removesDiacriticsTatweelAndDaggerAlef() {
        // رَحْمَـٰن  ->  رحمن
        val input = "\u0631\u064E\u062D\u0652\u0645\u064E\u0640\u0670\u0646"
        assertEquals("\u0631\u062D\u0645\u0646", ArabicText.normalize(input))
    }

    @Test
    fun unifiesAlefVariants() {
        assertEquals("\u0627\u0627\u0627\u0627", ArabicText.normalize("\u0623\u0625\u0622\u0671"))
    }

    @Test
    fun digitsRoundTrip() {
        assertEquals("\u0662\u0665\u0665", ArabicText.toArabicDigits(255))
        assertEquals("255", ArabicText.toLatinDigits("\u0662\u0665\u0665"))
    }
}

class AyahFilesTest {
    @Test
    fun fileNameIsPaddedWithLatinDigits() {
        assertEquals("002255.mp3", AyahFiles.name(2, 255))
        assertEquals("114006.mp3", AyahFiles.name(114, 6))
    }

    @Test
    fun urlUsesFolder() {
        assertEquals(
            "https://everyayah.com/data/Alafasy_128kbps/001001.mp3",
            AyahFiles.url("Alafasy_128kbps", 1, 1)
        )
    }
}

class ReciteTest {
    @Test
    fun uthmaniWordMatchesPlainSpeechSpelling() {
        // expected (Uthmani, with dagger alef): العلمين   heard (plain): العالمين
        val expected = "\u0671\u0644\u0652\u0639\u064E\u0640\u0670\u0644\u064E\u0645\u0650\u064A\u0646\u064E"
        val heard = "\u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0646"
        org.junit.Assert.assertTrue(Recite.matches(expected, heard))
    }

    @Test
    fun differentWordDoesNotMatch() {
        val expected = "\u0671\u0644\u0652\u0639\u064E\u0640\u0670\u0644\u064E\u0645\u0650\u064A\u0646\u064E"
        val heard = "\u0627\u0644\u0631\u062D\u0645\u0646"
        org.junit.Assert.assertFalse(Recite.matches(expected, heard))
    }

    @Test
    fun distanceBasics() {
        assertEquals(0, Recite.distance("abc", "abc"))
        assertEquals(1, Recite.distance("abc", "abd"))
        assertEquals(2, Recite.distance("", "ab"))
    }
}

class MushafTextTest {
    @Test
    fun hizbLabelFromQuarter() {
        assertEquals("", MushafText.hizbLabel(0))
        assertEquals("الحزب " + ArabicText.toArabicDigits(1), MushafText.hizbLabel(1))
        assertEquals("١/٤ الحزب " + ArabicText.toArabicDigits(1), MushafText.hizbLabel(2))
        assertEquals("١/٢ الحزب " + ArabicText.toArabicDigits(52), MushafText.hizbLabel(207))
        assertEquals("٣/٤ الحزب " + ArabicText.toArabicDigits(60), MushafText.hizbLabel(240))
    }
}
