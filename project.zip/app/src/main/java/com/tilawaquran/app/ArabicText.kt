package com.tilawaquran.app

object ArabicText {
    private val marks = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640\\u08D3-\\u08FF]")

    /** Removes tashkeel and unifies letter variants, for search only. Display text is never changed. */
    fun normalize(input: String): String {
        var s = marks.replace(input, "")
        s = s.replace('\u0623', '\u0627')
            .replace('\u0625', '\u0627')
            .replace('\u0622', '\u0627')
            .replace('\u0671', '\u0627')
            .replace('\u0649', '\u064A')
            .replace('\u0629', '\u0647')
        return s.trim()
    }

    fun toArabicDigits(n: Int): String =
        n.toString().map { '\u0660' + (it - '0') }.joinToString("")

    fun toLatinDigits(s: String): String =
        s.map { if (it in '\u0660'..'\u0669') '0' + (it - '\u0660') else it }.joinToString("")
}
