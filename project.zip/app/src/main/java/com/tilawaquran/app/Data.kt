package com.tilawaquran.app

import android.content.Context
import org.json.JSONArray

class Ayah(val text: String, val juz: Int, val page: Int, val plain: String, val hizbQuarter: Int = 0)

class Surah(
    val number: Int,
    val name: String,
    val english: String,
    val meccan: Boolean,
    val ayahs: List<Ayah>,
    val plainName: String
)

class SearchHit(val surah: Surah, val ayahNumber: Int)

object Quran {
    @Volatile
    var surahs: List<Surah> = emptyList()

    val loaded: Boolean get() = surahs.isNotEmpty()

    fun load(context: Context) {
        if (loaded) return
        val raw = context.assets.open("quran.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(raw)
        val list = ArrayList<Surah>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val ay = o.getJSONArray("ayahs")
            val ayahs = ArrayList<Ayah>(ay.length())
            for (j in 0 until ay.length()) {
                val a = ay.getJSONArray(j)
                val t = a.getString(0)
                ayahs.add(Ayah(t, a.getInt(1), a.getInt(2), ArabicText.normalize(t), if (a.length() > 3) a.getInt(3) else 0))
            }
            val name = o.getString("name")
            list.add(
                Surah(
                    o.getInt("n"), name, o.getString("en"),
                    o.getString("type") == "Meccan", ayahs, ArabicText.normalize(name)
                )
            )
        }
        val pg = ArrayList<ArrayList<Pair<Int, Int>>>()
        repeat(604) { pg.add(ArrayList()) }
        for (s in list) {
            for ((i, a) in s.ayahs.withIndex()) {
                if (a.page in 1..604) pg[a.page - 1].add(Pair(s.number, i + 1))
            }
        }
        pages = pg
        surahs = list
    }

    @Volatile
    var pages: List<List<Pair<Int, Int>>> = emptyList()

    fun pageEntries(page: Int): List<Pair<Int, Int>> = pages.getOrNull(page - 1) ?: emptyList()

    fun search(query: String, limit: Int = 300): List<SearchHit> {
        val q = ArabicText.normalize(query)
        if (q.length < 2) return emptyList()
        val out = ArrayList<SearchHit>()
        for (s in surahs) {
            for ((i, a) in s.ayahs.withIndex()) {
                if (a.plain.contains(q)) {
                    out.add(SearchHit(s, i + 1))
                    if (out.size >= limit) return out
                }
            }
        }
        return out
    }

    fun firstAyahOfJuz(juz: Int): Pair<Int, Int>? {
        for (s in surahs) {
            for ((i, a) in s.ayahs.withIndex()) {
                if (a.juz == juz) return Pair(s.number, i + 1)
            }
        }
        return null
    }
}
