package com.tilawaquran.app

import android.content.Context
import org.json.JSONArray
import java.util.Locale

class Reciter(val name: String, val folder: String)

object Reciters {
    @Volatile
    var list: List<Reciter> = emptyList()

    fun load(context: Context) {
        if (list.isNotEmpty()) return
        val raw = try {
            context.assets.open("reciters.json").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            return
        }
        val arr = JSONArray(raw)
        val out = ArrayList<Reciter>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Reciter(o.getString("name"), o.getString("folder")))
        }
        list = out
    }

    fun find(folder: String): Reciter? =
        list.firstOrNull { it.folder == folder } ?: list.firstOrNull()
}

object AyahFiles {
    fun name(surah: Int, ayah: Int): String = String.format(Locale.US, "%03d%03d.mp3", surah, ayah)

    fun url(folder: String, surah: Int, ayah: Int): String =
        "https://everyayah.com/data/" + folder + "/" + name(surah, ayah)
}
