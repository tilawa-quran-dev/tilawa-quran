package com.tilawaquran.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Pure text matching used by the recitation check (no Android dependencies, unit-tested). */
object Recite {
    /** Comparison key: no diacritics, unified letters, and no alef (spelling of long alef differs between Uthmani text and speech output). */
    fun key(w: String): String = ArabicText.normalize(w).replace("\u0627", "")

    fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    fun matches(expected: String, heard: String): Boolean {
        val a = key(expected)
        val b = key(heard)
        if (a.isEmpty() || b.isEmpty()) return false
        if (a == b) return true
        return a.length >= 4 && b.length >= 4 && distance(a, b) <= 1
    }

    fun wordsOf(text: String): List<String> = text.split(" ").filter { key(it).isNotEmpty() }

    fun dots(word: String): String = "\u2022".repeat(key(word).length.coerceIn(2, 8))
}

class ReciteSession(val surah: Surah, startAyah: Int) {
    var ayahNo by mutableIntStateOf(startAyah)
        private set
    var words by mutableStateOf(Recite.wordsOf(surah.ayahs[startAyah - 1].text))
        private set
    val marks = mutableStateListOf<Int>().apply { repeat(words.size) { add(0) } }
    var pos by mutableIntStateOf(0)
        private set
    var correct by mutableIntStateOf(0)
        private set
    var hints by mutableIntStateOf(0)
        private set
    var mistakes by mutableIntStateOf(0)
        private set
    var doneAyahs by mutableIntStateOf(0)
        private set
    var wrongAt by mutableIntStateOf(-1)
        private set
    var finished by mutableStateOf(false)
        private set

    fun feed(heard: String) {
        if (finished || pos >= words.size) return
        if (Recite.matches(words[pos], heard)) {
            marks[pos] = 1
            correct++
            advance()
        } else {
            mistakes++
            wrongAt = pos
        }
    }

    fun hint() {
        if (finished || pos >= words.size) return
        marks[pos] = 2
        hints++
        advance()
    }

    fun clearWrong() {
        wrongAt = -1
    }

    private fun advance() {
        pos++
        if (pos >= words.size) nextAyah()
    }

    private fun nextAyah() {
        doneAyahs++
        if (ayahNo < surah.ayahs.size) {
            ayahNo++
            words = Recite.wordsOf(surah.ayahs[ayahNo - 1].text)
            marks.clear()
            repeat(words.size) { marks.add(0) }
            pos = 0
        } else {
            finished = true
        }
    }
}

class Recognizer(private val ctx: Context, private val session: ReciteSession) {
    private val handler = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var consumed = 0
    private var errorsInRow = 0

    val available: Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    var listening by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set

    fun fail(message: String) {
        listening = false
        status = message
    }

    fun begin() {
        if (!available) {
            fail("خدمة التعرف على الكلام غير متوفرة في هاتفك (تحتاج تطبيق Google).")
            return
        }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(ctx)
            sr?.setRecognitionListener(listener)
        }
        errorsInRow = 0
        listening = true
        status = "أستمع إليك... ابدأ التلاوة"
        startOnce()
    }

    fun end() {
        listening = false
        status = ""
        handler.removeCallbacksAndMessages(null)
        sr?.cancel()
    }

    fun destroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        sr?.destroy()
        sr = null
    }

    private fun startOnce() {
        consumed = 0
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        sr?.startListening(i)
    }

    private fun restart(delayMs: Long) {
        handler.postDelayed({
            if (listening) {
                sr?.cancel()
                startOnce()
            }
        }, delayMs)
    }

    private fun handle(b: Bundle?, isFinal: Boolean) {
        val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        errorsInRow = 0
        val heard = text.split(" ").filter { it.isNotBlank() }
        val limit = if (isFinal) heard.size else heard.size - 1
        while (consumed < limit) {
            session.feed(heard[consumed])
            consumed++
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            handle(partialResults, false)
        }

        override fun onResults(results: Bundle?) {
            handle(results, true)
            consumed = 0
            if (listening && !session.finished) restart(300) else if (session.finished) end()
        }

        override fun onError(error: Int) {
            if (!listening) return
            errorsInRow++
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    fail("لا يوجد إذن للميكروفون.")
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER ->
                    fail("التعرف على الكلام يحتاج اتصالًا بالإنترنت. تحقق منه وأعد المحاولة.")
                else ->
                    if (errorsInRow > 8) fail("تعذّر التعرف على الصوت. حاول في مكان أهدأ أو أعد المحاولة.")
                    else restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 800L else 400L)
            }
        }
    }
}

@Composable
fun ReciteScreen(
    surahNumber: Int,
    startAyah: Int,
    font: FontFamily,
    prefs: Prefs,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val surah = Quran.surahs[surahNumber - 1]
    val session = remember { ReciteSession(surah, startAyah.coerceIn(1, surah.ayahs.size)) }
    val rec = remember { Recognizer(ctx, session) }

    DisposableEffect(Unit) {
        onDispose { rec.destroy() }
    }
    LaunchedEffect(session.wrongAt, session.mistakes) {
        if (session.wrongAt >= 0) {
            delay(900)
            session.clearWrong()
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            Audio.pause()
            rec.begin()
        } else {
            rec.fail("لا يمكن التسميع بدون إذن الميكروفون.")
        }
    }

    val good = Color(0xFF3FA66B)
    val bad = Color(0xFFE05555)

    Column(Modifier.fillMaxSize()) {
        TopBar("التسميع", onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                surah.name + " • آية " + ArabicText.toArabicDigits(session.ayahNo) +
                    " من " + ArabicText.toArabicDigits(surah.ayahs.size),
                color = Brand.Gold,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            val text = buildAnnotatedString {
                for (i in session.words.indices) {
                    val st = session.marks.getOrElse(i) { 0 }
                    when {
                        st == 1 -> withStyle(SpanStyle(color = good)) { append(session.words[i]) }
                        st == 2 -> withStyle(SpanStyle(color = Brand.Gold)) { append(session.words[i]) }
                        else -> withStyle(SpanStyle(color = if (i == session.wrongAt) bad else Color.Gray)) {
                            append(Recite.dots(session.words[i]))
                        }
                    }
                    append("  ")
                }
            }
            Text(
                text,
                fontFamily = font,
                fontSize = prefs.fontSize.sp,
                lineHeight = (prefs.fontSize * 1.9f).sp,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            if (session.finished) {
                Text("أحسنت، أتممت السورة ✓", color = good, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
            }
            if (rec.status.isNotEmpty()) {
                Text(rec.status, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(8.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (rec.listening) {
                            rec.end()
                        } else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            Audio.pause()
                            rec.begin()
                        } else {
                            launcher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    enabled = !session.finished
                ) { Text(if (rec.listening) "إيقاف" else "ابدأ التسميع") }
                TextButton(onClick = { session.hint() }, enabled = !session.finished) { Text("تلميح (إظهار الكلمة)") }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "الكلمات الصحيحة: " + ArabicText.toArabicDigits(session.correct) +
                    " • التلميحات: " + ArabicText.toArabicDigits(session.hints) +
                    " • المحاولات الخاطئة: " + ArabicText.toArabicDigits(session.mistakes) +
                    " • الآيات المكتملة: " + ArabicText.toArabicDigits(session.doneAyahs),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "ملاحظة: التعرف على الكلام يعتمد على خدمة هاتفك وقد يخطئ في بعض الكلمات، ولا يحكم على التجويد. " +
                    "إن علقت عند كلمة فاستخدم «تلميح». هذه أداة مساعدة ولا تغني عن مقرئ.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}
