package com.tilawaquran.app

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

class Zekr(val text: String, val count: Int)

class AdhkarCategory(val name: String, val plain: String, val items: List<Zekr>)

object Adhkar {
    @Volatile
    var categories: List<AdhkarCategory> = emptyList()

    fun load(context: Context) {
        if (categories.isNotEmpty()) return
        val raw = try {
            context.assets.open("adhkar.json").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            return
        }
        val arr = JSONArray(raw)
        val out = ArrayList<AdhkarCategory>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val items = o.getJSONArray("items")
            val list = ArrayList<Zekr>()
            for (j in 0 until items.length()) {
                val z = items.getJSONObject(j)
                list.add(Zekr(z.getString("text"), z.optInt("count", 1).coerceAtLeast(1)))
            }
            val name = o.getString("name")
            out.add(AdhkarCategory(name, ArabicText.normalize(name), list))
        }
        val featured = listOf(
            "أذكار الصباح والمساء",
            "أذكار النوم",
            "أذكار الاستيقاظ من النوم",
            "الأذكار بعد السلام من الصلاة"
        ).map { ArabicText.normalize(it) }
        categories = out.sortedBy { c ->
            val k = featured.indexOf(c.plain)
            if (k >= 0) k else 100
        }
    }
}

private fun vibrateOnce(ctx: Context) {
    try {
        val v = ctx.getSystemService(Vibrator::class.java)
        v?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Exception) {
    }
}

@Composable
fun AdhkarListScreen(onBack: () -> Unit, onTasbih: () -> Unit, onOpen: (Int) -> Unit) {
    var q by remember { mutableStateOf("") }
    val nq = ArabicText.normalize(q)
    val cats = Adhkar.categories
    val shown = cats.withIndex().filter { nq.isEmpty() || it.value.plain.contains(nq) }
    Column(Modifier.fillMaxSize()) {
        TopBar("الأذكار", onBack)
        LazyColumn(Modifier.fillMaxSize()) {
            item { MenuCard("السبحة الإلكترونية", "عدّاد بهدف واهتزاز اختياري، ويحفظ العدد", onTasbih) }
            item {
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    label = { Text("ابحث في الأذكار") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                )
            }
            if (cats.isEmpty()) {
                item {
                    Text(
                        "نصوص الأذكار غير متوفرة في هذه النسخة (تعذّر تنزيلها وقت البناء). السبحة تعمل بشكل طبيعي.",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
            items(shown) { iv ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(iv.index) }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(iv.value.name, fontSize = 18.sp, color = MaterialTheme.colorScheme.onBackground)
                    Text(
                        ArabicText.toArabicDigits(iv.value.items.size) + " ذكر",
                        fontSize = 12.sp,
                        color = Brand.Gold
                    )
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun AdhkarDetailScreen(catIndex: Int, font: FontFamily, prefs: Prefs, onBack: () -> Unit) {
    val cat = Adhkar.categories[catIndex]
    val remaining = remember(catIndex) {
        mutableStateListOf<Int>().apply { cat.items.forEach { add(it.count) } }
    }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar(
            title = cat.name,
            onBack = onBack,
            actions = { TextButton(onClick = { confirm = true }) { Text("إعادة العدّ", color = Brand.Gold) } }
        )
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(cat.items) { i, z ->
                val left = remaining.getOrElse(i) { 0 }
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (left == 0) Brand.Gold.copy(alpha = 0.18f)
                        else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .clickable { if (left > 0) remaining[i] = left - 1 }
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            z.text,
                            fontFamily = font,
                            fontSize = (prefs.fontSize * 0.8f).sp,
                            lineHeight = (prefs.fontSize * 0.8f * 1.8f).sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (left == 0) "تم ✓" else "اضغط للعدّ • المتبقي: " +
                                ArabicText.toArabicDigits(left) + " من " + ArabicText.toArabicDigits(z.count),
                            fontSize = 13.sp,
                            color = Brand.Gold
                        )
                    }
                }
            }
            item {
                Text(
                    "المصدر: كتاب «حصن المسلم» للشيخ سعيد القحطاني، عبر ملف rn0x/Adhkar-json. " +
                        "لم نراجع كل نص بنفسنا، فيُرجى التأكد من الكتاب الأصلي.",
                    fontSize = 11.sp,
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("إعادة العدّ؟") },
            text = { Text("ستعود كل عدّادات هذه القائمة إلى البداية.") },
            confirmButton = {
                TextButton(onClick = {
                    for (i in remaining.indices) remaining[i] = cat.items[i].count
                    confirm = false
                }) { Text("نعم") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun TasbihScreen(prefs: Prefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val phrases = listOf(
        "سبحان الله",
        "الحمد لله",
        "الله أكبر",
        "لا إله إلا الله",
        "أستغفر الله",
        "لا حول ولا قوة إلا بالله"
    )
    var confirm by remember { mutableStateOf(false) }
    val target = prefs.tasbihTarget
    Column(Modifier.fillMaxSize()) {
        TopBar("السبحة", onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                phrases.getOrElse(prefs.tasbihZekr) { phrases[0] },
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Brand.Gold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .background(Brand.Green)
                    .clickable {
                        prefs.tasbihAdd()
                        if (prefs.tasbihVibrate) vibrateOnce(ctx)
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    ArabicText.toArabicDigits(prefs.tasbihCount),
                    color = Brand.Gold,
                    fontSize = 64.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (target > 0) {
                    "الهدف: " + ArabicText.toArabicDigits(target) +
                        (if (prefs.tasbihCount >= target) "  •  تم الهدف ✓" else "")
                } else "بدون هدف",
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(12.dp))
            Text("الهدف", fontWeight = FontWeight.Bold, color = Brand.Gold)
            Row(horizontalArrangement = Arrangement.Center) {
                for (t in listOf(33, 99, 100, 0)) {
                    TextButton(onClick = { prefs.changeTasbihTarget(t) }) {
                        Text((if (target == t) "✓ " else "") + (if (t == 0) "بدون" else ArabicText.toArabicDigits(t)))
                    }
                }
            }
            Text("الذكر", fontWeight = FontWeight.Bold, color = Brand.Gold)
            for (i in phrases.indices) {
                TextButton(onClick = { prefs.changeTasbihZekr(i) }) {
                    Text((if (prefs.tasbihZekr == i) "✓ " else "") + phrases[i])
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("الاهتزاز عند العدّ", color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.size(12.dp))
                Switch(checked = prefs.tasbihVibrate, onCheckedChange = { prefs.changeTasbihVibrate(it) })
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { confirm = true }) { Text("تصفير العدّاد") }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("تصفير العدّاد؟") },
            text = { Text("سيعود العدد إلى صفر.") },
            confirmButton = {
                TextButton(onClick = { prefs.tasbihReset(); confirm = false }) { Text("نعم") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }
}
