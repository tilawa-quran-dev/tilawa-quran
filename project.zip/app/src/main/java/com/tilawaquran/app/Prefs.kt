package com.tilawaquran.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("tilawa", Context.MODE_PRIVATE)

    var lastSurah by mutableIntStateOf(sp.getInt("lastSurah", 0))
        private set
    var lastAyah by mutableIntStateOf(sp.getInt("lastAyah", 1))
        private set
    var fontSize by mutableFloatStateOf(sp.getFloat("fontSize", 28f))
        private set
    var dark by mutableStateOf<Boolean?>(
        if (sp.contains("dark")) sp.getBoolean("dark", false) else null
    )
        private set

    val bookmarks = mutableStateListOf<String>().apply {
        addAll(sp.getStringSet("bookmarks", emptySet()) ?: emptySet())
    }

    fun saveLast(surah: Int, ayah: Int) {
        if (surah == lastSurah && ayah == lastAyah) return
        lastSurah = surah
        lastAyah = ayah
        sp.edit().putInt("lastSurah", surah).putInt("lastAyah", ayah).apply()
    }

    fun changeFontSize(v: Float) {
        fontSize = v
        sp.edit().putFloat("fontSize", v).apply()
    }

    fun changeDark(v: Boolean) {
        dark = v
        sp.edit().putBoolean("dark", v).apply()
    }

    fun isBookmarked(surah: Int, ayah: Int): Boolean = bookmarks.contains("$surah:$ayah")

    fun toggleBookmark(surah: Int, ayah: Int) {
        val key = "$surah:$ayah"
        if (bookmarks.contains(key)) bookmarks.remove(key) else bookmarks.add(key)
        sp.edit().putStringSet("bookmarks", bookmarks.toSet()).apply()
    }
}
