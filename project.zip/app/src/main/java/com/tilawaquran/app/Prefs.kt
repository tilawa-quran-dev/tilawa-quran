package com.tilawaquran.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("tilawa", Context.MODE_PRIVATE)

    var lastSurah by mutableIntStateOf(sp.getInt("lastSurah", 0))
        private set
    var lastAyah by mutableIntStateOf(sp.getInt("lastAyah", 1))
        private set
    var fontSize by mutableFloatStateOf(sp.getFloat("fontSize", 28f))
        private set
    var dark by mutableStateOf<Boolean?>(
        if (sp.contains("dark")) sp.getBoolean("dark", false) else null
    )
        private set

    var reciter by mutableStateOf(sp.getString("reciter", "") ?: "")
        private set

    var lastPage by mutableIntStateOf(sp.getInt("lastPage", 1))
        private set
    var tasbihCount by mutableIntStateOf(sp.getInt("tasbihCount", 0))
        private set
    var tasbihTarget by mutableIntStateOf(sp.getInt("tasbihTarget", 33))
        private set
    var tasbihZekr by mutableIntStateOf(sp.getInt("tasbihZekr", 0))
        private set
    var tasbihVibrate by mutableStateOf(sp.getBoolean("tasbihVibrate", true))
        private set

    val bookmarks = mutableStateListOf<String>().apply {
        addAll(sp.getStringSet("bookmarks", emptySet()) ?: emptySet())
    }

    fun saveLast(surah: Int, ayah: Int) {
        if (surah == lastSurah && ayah == lastAyah) return
        lastSurah = surah
        lastAyah = ayah
        sp.edit().putInt("lastSurah", surah).putInt("lastAyah", ayah).apply()
    }

    fun changeFontSize(v: Float) {
        fontSize = v
        sp.edit().putFloat("fontSize", v).apply()
    }

    fun changeDark(v: Boolean) {
        dark = v
        sp.edit().putBoolean("dark", v).apply()
    }

    fun changeReciter(folder: String) {
        reciter = folder
        sp.edit().putString("reciter", folder).apply()
    }

    fun saveLastPage(p: Int) {
        if (p == lastPage) return
        lastPage = p
        sp.edit().putInt("lastPage", p).apply()
    }

    fun tasbihAdd() {
        tasbihCount += 1
        sp.edit().putInt("tasbihCount", tasbihCount).apply()
    }

    fun tasbihReset() {
        tasbihCount = 0
        sp.edit().putInt("tasbihCount", 0).apply()
    }

    fun changeTasbihTarget(v: Int) {
        tasbihTarget = v
        sp.edit().putInt("tasbihTarget", v).apply()
    }

    fun changeTasbihZekr(i: Int) {
        tasbihZekr = i
        sp.edit().putInt("tasbihZekr", i).apply()
    }

    fun changeTasbihVibrate(v: Boolean) {
        tasbihVibrate = v
        sp.edit().putBoolean("tasbihVibrate", v).apply()
    }

    fun isBookmarked(surah: Int, ayah: Int): Boolean = bookmarks.contains("$surah:$ayah")

    fun toggleBookmark(surah: Int, ayah: Int) {
        val key = "$surah:$ayah"
        if (bookmarks.contains(key)) bookmarks.remove(key) else bookmarks.add(key)
        sp.edit().putStringSet("bookmarks", bookmarks.toSet()).apply()
    }
}
