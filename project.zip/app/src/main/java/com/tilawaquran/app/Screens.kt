package com.tilawaquran.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun ayahLabel(n: Int) = "آية " + ArabicText.toArabicDigits(n)

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brand.Green)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            TextButton(onClick = onBack) { Text("رجوع", color = Brand.Gold) }
        }
        Text(
            text = title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        )
        actions()
    }
}

@Composable
fun SplashScreen(error: String?) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Green),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("تلاوة", color = Brand.Gold, fontSize = 64.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("رفيقك مع القرآن الكريم", color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(32.dp))
            if (error != null) {
                Text(error, color = Color.White, modifier = Modifier.padding(24.dp), textAlign = TextAlign.Center)
            } else {
                CircularProgressIndicator(color = Brand.Gold)
            }
        }
    }
}

@Composable
private fun MenuCard(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            if (subtitle != null) {
                Spacer(Modifier.height(4.dp))
                Text(subtitle, fontSize = 14.sp, color = Brand.Gold)
            }
        }
    }
}

@Composable
fun HomeScreen(
    prefs: Prefs,
    onContinue: () -> Unit,
    onIndex: () -> Unit,
    onSearch: () -> Unit,
    onBookmarks: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brand.Green)
                .padding(vertical = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("تلاوة", color = Brand.Gold, fontSize = 52.sp, fontWeight = FontWeight.Bold)
            Text("رفيقك مع القرآن الكريم", color = Color.White, fontSize = 16.sp)
        }
        Spacer(Modifier.height(12.dp))
        if (prefs.lastSurah in 1..114 && Quran.loaded) {
            val s = Quran.surahs[prefs.lastSurah - 1]
            MenuCard("متابعة القراءة", s.name + " • " + ayahLabel(prefs.lastAyah), onContinue)
        }
        MenuCard("فهرس السور والأجزاء", "١١٤ سورة و٣٠ جزءًا", onIndex)
        MenuCard("البحث", "ابحث بكلمة أو باسم سورة", onSearch)
        MenuCard("العلامات المرجعية", "الآيات التي حفظتها", onBookmarks)
        MenuCard("الإعدادات", "الخط والوضع الليلي ومعلومات التطبيق", onSettings)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun TabButton(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .background(if (selected) Brand.GreenLight else Brand.Green)
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) Brand.Gold else Color.White,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
fun IndexScreen(onBack: () -> Unit, onOpen: (Int, Int) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val juzStarts = remember { (1..30).map { Quran.firstAyahOfJuz(it) } }
    Column(Modifier.fillMaxSize()) {
        TopBar("الفهرس", onBack)
        Row(Modifier.fillMaxWidth()) {
            TabButton("السور", tab == 0, Modifier.weight(1f)) { tab = 0 }
            TabButton("الأجزاء", tab == 1, Modifier.weight(1f)) { tab = 1 }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            if (tab == 0) {
                items(Quran.surahs) { s ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(s.number, 0) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            ArabicText.toArabicDigits(s.number),
                            color = Brand.Gold,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 16.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontSize = 20.sp, color = MaterialTheme.colorScheme.onBackground)
                            Text(
                                (if (s.meccan) "مكية" else "مدنية") + " • " +
                                    ArabicText.toArabicDigits(s.ayahs.size) + " آية",
                                fontSize = 13.sp,
                                color = Brand.Gold
                            )
                        }
                    }
                    HorizontalDivider()
                }
            } else {
                items((1..30).toList()) { j ->
                    val start = juzStarts[j - 1]
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { if (start != null) onOpen(start.first, start.second) }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Text(
                            "الجزء " + ArabicText.toArabicDigits(j),
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        if (start != null) {
                            Text(
                                Quran.surahs[start.first - 1].name + " • " + ayahLabel(start.second),
                                fontSize = 13.sp,
                                color = Brand.Gold
                            )
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

private fun requestNotifications(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) {
        (ctx as? Activity)?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
}

@Composable
fun ReaderScreen(
    surahNumber: Int,
    startAyah: Int,
    highlight: Int,
    prefs: Prefs,
    font: FontFamily,
    onBack: () -> Unit,
    onRecite: (Int) -> Unit
) {
    val surah = Quran.surahs[surahNumber - 1]
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = startAyah.coerceIn(0, surah.ayahs.size)
    )
    var selected by remember { mutableStateOf(0) }
    var showOptions by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(-1) }
    var downloadMsg by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val reciter = Reciters.find(prefs.reciter)
    val loadedHere = Audio.currentSurah == surahNumber
    val playingHere = loadedHere && Audio.isPlaying
    val audioAyah = if (loadedHere) Audio.currentAyah else 0
    val dlCount = remember(prefs.reciter, progress, showOptions) {
        if (reciter != null) Downloader.downloadedCount(ctx, reciter, surah) else 0
    }

    val dlTotal = if (reciter != null) Downloader.total(reciter, surah) else 0

    fun play(from: Int) {
        if (reciter == null) return
        requestNotifications(ctx)
        Audio.playSurah(ctx, surah, from, reciter)
    }

    fun pickReciter(r: Reciter) {
        prefs.changeReciter(r.folder)
        if (loadedHere && Audio.isPlaying) {
            Audio.playSurah(ctx, surah, Audio.currentAyah.coerceAtLeast(1), r)
        }
    }

    LaunchedEffect(surahNumber) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { idx ->
            prefs.saveLast(surahNumber, idx.coerceIn(1, surah.ayahs.size))
        }
    }

    LaunchedEffect(audioAyah) {
        if (audioAyah > 0 && Audio.isPlaying) {
            listState.animateScrollToItem(audioAyah)
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(
            title = surah.name,
            onBack = onBack,
            actions = {
                TextButton(onClick = { prefs.changeFontSize((prefs.fontSize - 2f).coerceAtLeast(18f)) }) {
                    Text("أ-", color = Brand.Gold, fontSize = 18.sp)
                }
                TextButton(onClick = { prefs.changeFontSize((prefs.fontSize + 2f).coerceAtMost(44f)) }) {
                    Text("أ+", color = Brand.Gold, fontSize = 18.sp)
                }
            }
        )
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        surah.name,
                        fontFamily = font,
                        fontSize = (prefs.fontSize + 6f).sp,
                        color = Brand.Gold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        (if (surah.meccan) "مكية" else "مدنية") + " • " +
                            ArabicText.toArabicDigits(surah.ayahs.size) + " آية",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    if (surah.number != 1 && surah.number != 9) {
                        Spacer(Modifier.height(16.dp))
                        Text(
                            Quran.surahs[0].ayahs[0].text,
                            fontFamily = font,
                            fontSize = prefs.fontSize.sp,
                            lineHeight = (prefs.fontSize * 1.9f).sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
                HorizontalDivider()
            }
            itemsIndexed(surah.ayahs) { i, a ->
                val n = i + 1
                val bg = when {
                    audioAyah > 0 && n == audioAyah -> Brand.Gold.copy(alpha = 0.30f)
                    n == highlight -> Brand.Gold.copy(alpha = 0.18f)
                    else -> Color.Transparent
                }
                val marked = prefs.isBookmarked(surahNumber, n)
                val text = buildAnnotatedString {
                    append(a.text)
                    append(" ")
                    withStyle(SpanStyle(color = Brand.Gold, fontWeight = FontWeight.Bold)) {
                        append("\uFD3F" + ArabicText.toArabicDigits(n) + "\uFD3E")
                        if (marked) append(" \u2605")
                    }
                }
                Text(
                    text = text,
                    fontFamily = font,
                    fontSize = prefs.fontSize.sp,
                    lineHeight = (prefs.fontSize * 1.9f).sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(bg)
                        .clickable { selected = n }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brand.Green)
                .padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { Audio.previous() }, enabled = Audio.ready && loadedHere && reciter?.surahLevel != true) {
                Text("السابق", color = Brand.Gold)
            }
            TextButton(
                onClick = {
                    if (loadedHere) Audio.togglePlay()
                    else play(listState.firstVisibleItemIndex.coerceAtLeast(1))
                },
                enabled = Audio.ready && reciter != null && reciter.hasSurah(surahNumber)
            ) {
                Text(
                    if (reciter != null && !reciter.hasSurah(surahNumber)) "السورة غير متوفرة" else if (playingHere) "إيقاف مؤقت" else "تشغيل",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            TextButton(onClick = { Audio.next() }, enabled = Audio.ready && loadedHere && reciter?.surahLevel != true) {
                Text("التالي", color = Brand.Gold)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { showOptions = true }) {
                Text("خيارات الصوت", color = Brand.Gold)
            }
        }
    }

    if (selected > 0) {
        val n = selected
        val a = surah.ayahs[n - 1]
        val marked = prefs.isBookmarked(surahNumber, n)
        val shareText = "\uFD3F" + a.text + "\uFD3E\n[" + surah.name + ": " + n + "]\n— تطبيق تلاوة"
        AlertDialog(
            onDismissRequest = { selected = 0 },
            confirmButton = { TextButton(onClick = { selected = 0 }) { Text("إغلاق") } },
            title = { Text(surah.name + " • " + ayahLabel(n)) },
            text = {
                Column {
                    TextButton(
                        onClick = { play(n); selected = 0 },
                        enabled = Audio.ready && reciter != null && !reciter.surahLevel
                    ) { Text("تشغيل من هذه الآية") }
                    TextButton(onClick = { onRecite(n); selected = 0 }) { Text("تسميع من هذه الآية") }
                    TextButton(onClick = { prefs.toggleBookmark(surahNumber, n); selected = 0 }) {
                        Text(if (marked) "إزالة العلامة المرجعية" else "إضافة علامة مرجعية")
                    }
                    TextButton(onClick = { clipboard.setText(AnnotatedString(shareText)); selected = 0 }) {
                        Text("نسخ الآية")
                    }
                    TextButton(onClick = {
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        ctx.startActivity(Intent.createChooser(i, null))
                        selected = 0
                    }) { Text("مشاركة الآية") }
                }
            }
        )
    }

    if (showOptions) {
        AlertDialog(
            onDismissRequest = { showOptions = false },
            confirmButton = { TextButton(onClick = { showOptions = false }) { Text("إغلاق") } },
            title = { Text("خيارات الصوت") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (Reciters.list.isEmpty()) {
                        Text("قائمة القرّاء غير متوفرة في هذه النسخة (تعذّر التحقق منها وقت البناء).")
                    }
                    Text("القارئ", fontWeight = FontWeight.Bold, color = Brand.Gold)
                    for (r in Reciters.list) {
                        TextButton(onClick = { pickReciter(r) }) {
                            Text((if (r.folder == reciter?.folder) "✓ " else "") + r.name)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("السرعة", fontWeight = FontWeight.Bold, color = Brand.Gold)
                    Row {
                        for (v in listOf(0.75f, 1f, 1.25f, 1.5f)) {
                            TextButton(onClick = { Audio.changeSpeed(v) }) {
                                Text((if (Audio.speed == v) "✓" else "") + v.toString() + "x", fontSize = 13.sp)
                            }
                        }
                    }
                    Text("التكرار", fontWeight = FontWeight.Bold, color = Brand.Gold)
                    val repeatLabels = listOf("بدون تكرار", "تكرار الآية", "تكرار السورة")
                    for (m in 0..2) {
                        TextButton(onClick = { Audio.changeRepeat(m) }) {
                            Text((if (Audio.repeatMode == m) "✓ " else "") + repeatLabels[m])
                        }
                    }
                    Text("إيقاف تلقائي بعد (دقيقة)", fontWeight = FontWeight.Bold, color = Brand.Gold)
                    Row {
                        for (m in listOf(15, 30, 60, 0)) {
                            TextButton(onClick = { Audio.changeSleep(m) }) {
                                Text(
                                    (if (Audio.sleepMinutes == m) "✓" else "") +
                                        (if (m == 0) "إلغاء" else m.toString()),
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("الاستماع دون إنترنت", fontWeight = FontWeight.Bold, color = Brand.Gold)
                    if (reciter != null) {
                        Text(
                            if (progress >= 0) {
                                "جارٍ التحميل: " + ArabicText.toArabicDigits(progress) + " من " +
                                    ArabicText.toArabicDigits(dlTotal) + " (ابقَ في هذه الشاشة)"
                            } else if (dlCount == dlTotal) {
                                "السورة محمّلة بصوت " + reciter.name + " ✓"
                            } else {
                                "المحمّل: " + ArabicText.toArabicDigits(dlCount) + " من " +
                                    ArabicText.toArabicDigits(dlTotal) + " آية"
                            },
                            fontSize = 13.sp
                        )
                        if (downloadMsg.isNotEmpty()) Text(downloadMsg, fontSize = 13.sp)
                        TextButton(
                            onClick = {
                                downloadMsg = ""
                                scope.launch {
                                    progress = 0
                                    val ok = Downloader.downloadSurah(ctx, reciter, surah) { progress = it }
                                    progress = -1
                                    downloadMsg = if (ok) "تم التحميل" else "تعذّر التحميل. تحقق من الإنترنت وأعد المحاولة."
                                }
                            },
                            enabled = progress < 0 && dlCount < dlTotal
                        ) { Text("تحميل السورة") }
                        TextButton(
                            onClick = { Downloader.deleteSurah(ctx, reciter, surah); downloadMsg = "تم الحذف"; progress = -1 },
                            enabled = progress < 0 && dlCount > 0
                        ) { Text("حذف التحميل") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("مصدر الصوت: EveryAyah.com", fontSize = 12.sp)
                }
            }
        )
    }
}

@Composable
fun SearchScreen(font: FontFamily, onBack: () -> Unit, onOpen: (Int, Int) -> Unit) {
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<SearchHit>>(emptyList()) }

    LaunchedEffect(q) {
        delay(250)
        val query = q
        results = withContext(Dispatchers.Default) { Quran.search(query) }
    }

    val latin = ArabicText.toLatinDigits(q.trim())
    val jump = Regex("^(\\d+)\\s*[:/\\-\\s]\\s*(\\d+)$").find(latin)
    val jumpTarget: Pair<Int, Int>? = jump?.let {
        val s = it.groupValues[1].toInt()
        val a = it.groupValues[2].toInt()
        if (s in 1..114 && a in 1..Quran.surahs[s - 1].ayahs.size) Pair(s, a) else null
    }
    val nq = ArabicText.normalize(q)
    val surahMatches = when {
        latin.isNotEmpty() && latin.all { it.isDigit() } && latin.length <= 3 -> {
            val n = latin.toInt()
            if (n in 1..114) listOf(Quran.surahs[n - 1]) else emptyList()
        }
        nq.length >= 2 -> Quran.surahs.filter { it.plainName.contains(nq) }
        else -> emptyList()
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("البحث", onBack)
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            label = { Text("كلمة، اسم سورة، أو رقم مثل 2:255") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        )
        LazyColumn(Modifier.fillMaxSize()) {
            if (jumpTarget != null) {
                item {
                    TextButton(onClick = { onOpen(jumpTarget.first, jumpTarget.second) }) {
                        Text("الانتقال إلى " + Quran.surahs[jumpTarget.first - 1].name + " • " + ayahLabel(jumpTarget.second))
                    }
                }
            }
            items(surahMatches) { s ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(s.number, 0) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text("سورة: " + s.name, fontSize = 18.sp, color = MaterialTheme.colorScheme.onBackground)
                }
                HorizontalDivider()
            }
            if (results.isNotEmpty()) {
                item {
                    Text(
                        "نتائج الآيات: " + ArabicText.toArabicDigits(results.size) +
                            (if (results.size >= 300) " (أول ٣٠٠ نتيجة)" else ""),
                        color = Brand.Gold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
            items(results) { h ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(h.surah.number, h.ayahNumber) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(h.surah.name + " • " + ayahLabel(h.ayahNumber), color = Brand.Gold, fontSize = 13.sp)
                    Text(
                        h.surah.ayahs[h.ayahNumber - 1].text,
                        fontFamily = font,
                        fontSize = 22.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                HorizontalDivider()
            }
            if (nq.length >= 2 && results.isEmpty() && surahMatches.isEmpty() && jumpTarget == null) {
                item {
                    Text(
                        "لا توجد نتائج. جرّب كلمة أخرى.",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }
}

@Composable
fun BookmarksScreen(prefs: Prefs, font: FontFamily, onBack: () -> Unit, onOpen: (Int, Int) -> Unit) {
    val items = prefs.bookmarks
        .mapNotNull { key ->
            val p = key.split(":")
            val s = p.getOrNull(0)?.toIntOrNull()
            val a = p.getOrNull(1)?.toIntOrNull()
            if (s != null && a != null && s in 1..114) Pair(s, a) else null
        }
        .sortedWith(compareBy({ it.first }, { it.second }))

    Column(Modifier.fillMaxSize()) {
        TopBar("العلامات المرجعية", onBack)
        if (items.isEmpty()) {
            Text(
                "لا توجد علامات بعد. اضغط على أي آية أثناء القراءة ثم اختر «إضافة علامة مرجعية».",
                modifier = Modifier.padding(24.dp),
                color = MaterialTheme.colorScheme.onBackground
            )
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(items) { (sn, an) ->
                val s = Quran.surahs[sn - 1]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        Modifier
                            .weight(1f)
                            .clickable { onOpen(sn, an) }
                    ) {
                        Text(s.name + " • " + ayahLabel(an), color = Brand.Gold, fontSize = 13.sp)
                        Text(
                            s.ayahs[an - 1].text,
                            fontFamily = font,
                            fontSize = 22.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    TextButton(onClick = { prefs.toggleBookmark(sn, an) }) { Text("حذف") }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun SettingsScreen(prefs: Prefs, font: FontFamily, onBack: () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    Column(Modifier.fillMaxSize()) {
        TopBar("الإعدادات", onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(
                    "الوضع الليلي",
                    fontSize = 18.sp,
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Switch(checked = prefs.dark ?: systemDark, onCheckedChange = { prefs.changeDark(it) })
            }
            Spacer(Modifier.height(24.dp))
            Text("حجم الخط", fontSize = 18.sp, color = MaterialTheme.colorScheme.onBackground)
            Slider(
                value = prefs.fontSize,
                onValueChange = { prefs.changeFontSize(it) },
                valueRange = 18f..44f
            )
            Text(
                Quran.surahs[0].ayahs[0].text,
                fontFamily = font,
                fontSize = prefs.fontSize.sp,
                lineHeight = (prefs.fontSize * 1.9f).sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(32.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))
            Text("عن التطبيق", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Brand.Gold)
            Spacer(Modifier.height(8.dp))
            Text(
                "تلاوة — الإصدار ٠٫١ (نسخة أولية).\n\n" +
                    "نص القرآن: النص العثماني من مشروع Tanzil (tanzil.net) دون أي تعديل على الحروف أو التشكيل. " +
                    "النص مضمّن في التطبيق ويعمل دون إنترنت.\n\n" +
                    "الخط: Amiri Quran (رخصة SIL OFL).\n\n" +
                    "المتوفر الآن: الفهرس، القراءة، البحث، العلامات المرجعية، حفظ آخر موضع، والتلاوات الصوتية. " +
                    "التلاوات: من موقع EveryAyah.com، وتُشغَّل عبر الإنترنت أو من الملفات المحمّلة. " +
                    "التسميع تجريبي ويعتمد على خدمة التعرف على الكلام في هاتفك. التفسير والأذكار ومواقيت الصلاة قيد التطوير ولم تُضف بعد.",
                color = MaterialTheme.colorScheme.onBackground,
                lineHeight = 24.sp
            )
        }
    }
}
