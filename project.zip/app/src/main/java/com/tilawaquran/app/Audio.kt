package com.tilawaquran.app

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import java.io.File

object Audio {
    private var controller: MediaController? = null
    private var connecting = false
    private val handler = Handler(Looper.getMainLooper())
    private val sleepTask = Runnable {
        controller?.pause()
        sleepMinutes = 0
    }

    var ready by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var currentSurah by mutableIntStateOf(0)
        private set
    var currentAyah by mutableIntStateOf(0)
        private set
    var speed by mutableFloatStateOf(1f)
        private set
    var repeatMode by mutableIntStateOf(0) // 0 none, 1 ayah, 2 surah
        private set
    var sleepMinutes by mutableIntStateOf(0)
        private set

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            this@Audio.isPlaying = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            parse(mediaItem?.mediaId)
        }
    }

    private fun parse(id: String?) {
        val p = id?.split(":") ?: return
        val s = p.getOrNull(0)?.toIntOrNull() ?: return
        val a = p.getOrNull(1)?.toIntOrNull() ?: return
        currentSurah = s
        currentAyah = a
    }

    fun connect(context: Context) {
        if (controller != null || connecting) return
        connecting = true
        val app = context.applicationContext
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                isPlaying = c.isPlaying
                ready = true
            } catch (e: Exception) {
                connecting = false
            }
        }, ContextCompat.getMainExecutor(app))
    }

    fun audioFile(context: Context, r: Reciter, surah: Int, ayah: Int): File =
        File(context.filesDir, "audio/" + r.folder + "/" + AyahFiles.name(surah, ayah))

    fun playSurah(context: Context, surah: Surah, fromAyah: Int, reciter: Reciter) {
        val c = controller ?: return
        val items = surah.ayahs.indices.map { i ->
            val a = i + 1
            val f = audioFile(context, reciter, surah.number, a)
            val uri: Uri = if (f.exists()) Uri.fromFile(f)
            else Uri.parse(AyahFiles.url(reciter.folder, surah.number, a))
            MediaItem.Builder()
                .setMediaId(surah.number.toString() + ":" + a)
                .setUri(uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(surah.name)
                        .setArtist(reciter.name)
                        .build()
                )
                .build()
        }
        c.setMediaItems(items, (fromAyah - 1).coerceIn(0, items.size - 1), 0L)
        c.setPlaybackSpeed(speed)
        applyRepeat(c)
        c.prepare()
        c.play()
    }

    private fun applyRepeat(c: MediaController) {
        c.repeatMode = when (repeatMode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPreviousMediaItem()
    }

    fun changeSpeed(v: Float) {
        speed = v
        controller?.setPlaybackSpeed(v)
    }

    fun changeRepeat(mode: Int) {
        repeatMode = mode
        controller?.let { applyRepeat(it) }
    }

    fun changeSleep(minutes: Int) {
        handler.removeCallbacks(sleepTask)
        sleepMinutes = minutes
        if (minutes > 0) handler.postDelayed(sleepTask, minutes * 60_000L)
    }
}
