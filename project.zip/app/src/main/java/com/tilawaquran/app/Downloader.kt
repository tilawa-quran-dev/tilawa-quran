package com.tilawaquran.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Downloader {
    fun total(r: Reciter, surah: Surah): Int = if (r.surahLevel) 1 else surah.ayahs.size

    fun downloadedCount(context: Context, r: Reciter, surah: Surah): Int =
        if (r.surahLevel) {
            if (Audio.audioFile(context, r, surah.number, 1).exists()) 1 else 0
        } else {
            surah.ayahs.indices.count { Audio.audioFile(context, r, surah.number, it + 1).exists() }
        }

    fun deleteSurah(context: Context, r: Reciter, surah: Surah) {
        if (r.surahLevel) {
            Audio.audioFile(context, r, surah.number, 1).delete()
            return
        }
        for (i in surah.ayahs.indices) {
            Audio.audioFile(context, r, surah.number, i + 1).delete()
        }
    }

    suspend fun downloadSurah(
        context: Context,
        r: Reciter,
        surah: Surah,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (r.surahLevel) {
            val f = Audio.audioFile(context, r, surah.number, 1)
            if (f.exists()) return@withContext true
            val ok = fetch(r.base + AyahFiles.surahName(surah.number), f)
            if (ok) onProgress(1)
            return@withContext ok
        }
        var done = 0
        for (i in surah.ayahs.indices) {
            val f = Audio.audioFile(context, r, surah.number, i + 1)
            if (!f.exists()) {
                if (!fetch(AyahFiles.url(r.folder, surah.number, i + 1), f)) {
                    return@withContext false
                }
            }
            done++
            onProgress(done)
        }
        true
    }

    private fun fetch(url: String, dest: File): Boolean {
        var conn: HttpURLConnection? = null
        try {
            dest.parentFile?.mkdirs()
            val tmp = File(dest.path + ".part")
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            if (conn.responseCode != 200) return false
            conn.inputStream.use { input ->
                tmp.outputStream().use { out -> input.copyTo(out) }
            }
            return tmp.renameTo(dest)
        } catch (e: Exception) {
            return false
        } finally {
            conn?.disconnect()
        }
    }
}
