package com.tilawaquran.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Downloader {
    fun downloadedCount(context: Context, r: Reciter, surah: Surah): Int =
        surah.ayahs.indices.count { Audio.audioFile(context, r, surah.number, it + 1).exists() }

    fun deleteSurah(context: Context, r: Reciter, surah: Surah) {
        for (i in surah.ayahs.indices) {
            Audio.audioFile(context, r, surah.number, i + 1).delete()
        }
    }

    suspend fun downloadSurah(
        context: Context,
        r: Reciter,
        surah: Surah,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        var done = 0
        for (i in surah.ayahs.indices) {
            val f = Audio.audioFile(context, r, surah.number, i + 1)
            if (!f.exists()) {
                if (!fetch(AyahFiles.url(r.folder, surah.number, i + 1), f)) {
                    return@withContext false
                }
            }
            done++
            onProgress(done)
        }
        true
    }

    private fun fetch(url: String, dest: File): Boolean {
        var conn: HttpURLConnection? = null
        try {
            dest.parentFile?.mkdirs()
            val tmp = File(dest.path + ".part")
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            if (conn.responseCode != 200) return false
            conn.inputStream.use { input ->
                tmp.outputStream().use { out -> input.copyTo(out) }
            }
            return tmp.renameTo(dest)
        } catch (e: Exception) {
            return false
        } finally {
            conn?.disconnect()
        }
    }
}
