package com.tilawaquran.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TilawaApp() }
    }
}

sealed class Screen {
    object Splash : Screen()
    object Home : Screen()
    object Index : Screen()
    object Search : Screen()
    object Bookmarks : Screen()
    object Settings : Screen()
    data class Recite(val surah: Int, val ayah: Int) : Screen()
    data class Reader(val surah: Int, val ayah: Int, val highlight: Int = 0) : Screen()
}

object Brand {
    val Green = Color(0xFF0B3D2E)
    val GreenLight = Color(0xFF14573F)
    val Gold = Color(0xFFC9A227)
    val Cream = Color(0xFFFBF8F0)
    val Night = Color(0xFF0E1A15)
    val NightCard = Color(0xFF16291F)
}

private val LightColors = lightColorScheme(
    primary = Brand.Green,
    onPrimary = Color.White,
    secondary = Brand.Gold,
    background = Brand.Cream,
    surface = Color.White,
    onBackground = Color(0xFF1B2B24),
    onSurface = Color(0xFF1B2B24)
)

private val DarkColors = darkColorScheme(
    primary = Brand.Gold,
    onPrimary = Brand.Night,
    secondary = Brand.Gold,
    background = Brand.Night,
    surface = Brand.NightCard,
    onBackground = Color(0xFFEDE7D5),
    onSurface = Color(0xFFEDE7D5)
)

@Composable
fun TilawaApp() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val stack = remember { mutableStateListOf<Screen>(Screen.Splash) }
    var error by remember { mutableStateOf<String?>(null) }

    val font = remember {
        try {
            FontFamily(android.graphics.Typeface.createFromAsset(ctx.assets, "fonts/AmiriQuran.ttf"))
        } catch (e: Exception) {
            FontFamily.Default
        }
    }

    LaunchedEffect(Unit) {
        try {
            val start = System.currentTimeMillis()
            withContext(Dispatchers.Default) {
                Quran.load(ctx.applicationContext)
                Reciters.load(ctx.applicationContext)
            }
            Audio.connect(ctx)
            val rest = 1200 - (System.currentTimeMillis() - start)
            if (rest > 0) delay(rest)
            stack.clear()
            stack.add(Screen.Home)
        } catch (e: Exception) {
            error = "تعذر تحميل نص القرآن: " + e.message
        }
    }

    val dark = prefs.dark ?: isSystemInDarkTheme()
    val current = stack.last()

    BackHandler(enabled = stack.size > 1) { stack.removeAt(stack.lastIndex) }

    fun go(s: Screen) { stack.add(s) }
    fun back() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(color = MaterialTheme.colorScheme.background) {
                when (val s = current) {
                    is Screen.Splash -> SplashScreen(error)
                    is Screen.Home -> HomeScreen(
                        prefs = prefs,
                        onContinue = { go(Screen.Reader(prefs.lastSurah, prefs.lastAyah)) },
                        onIndex = { go(Screen.Index) },
                        onSearch = { go(Screen.Search) },
                        onBookmarks = { go(Screen.Bookmarks) },
                        onSettings = { go(Screen.Settings) }
                    )
                    is Screen.Index -> IndexScreen(
                        onBack = { back() },
                        onOpen = { sn, an -> go(Screen.Reader(sn, an)) }
                    )
                    is Screen.Search -> SearchScreen(
                        font = font,
                        onBack = { back() },
                        onOpen = { sn, an -> go(Screen.Reader(sn, an, an)) }
                    )
                    is Screen.Bookmarks -> BookmarksScreen(
                        prefs = prefs,
                        font = font,
                        onBack = { back() },
                        onOpen = { sn, an -> go(Screen.Reader(sn, an, an)) }
                    )
                    is Screen.Settings -> SettingsScreen(prefs = prefs, font = font, onBack = { back() })
                    is Screen.Reader -> ReaderScreen(
                        surahNumber = s.surah,
                        startAyah = s.ayah,
                        highlight = s.highlight,
                        prefs = prefs,
                        font = font,
                        onBack = { back() },
                        onRecite = { a -> go(Screen.Recite(s.surah, a)) }
                    )
                    is Screen.Recite -> ReciteScreen(
                        surahNumber = s.surah,
                        startAyah = s.ayah,
                        font = font,
                        prefs = prefs,
                        onBack = { back() }
                    )
                }
            }
        }
    }
}
