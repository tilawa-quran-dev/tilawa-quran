package com.tilawaquran.app

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object MushafText {
    /** Label for the quarter-hizb number (1..240), e.g. quarter 2 -> "١/٤ الحزب ١". */
    fun hizbLabel(quarter: Int): String {
        if (quarter <= 0) return ""
        val hizb = (quarter - 1) / 4 + 1
        val frac = when ((quarter - 1) % 4) {
            1 -> "١/٤ "
            2 -> "١/٢ "
            3 -> "٣/٤ "
            else -> ""
        }
        return frac + "الحزب " + ArabicText.toArabicDigits(hizb)
    }
}

@Composable
fun MushafScreen(startPage: Int, prefs: Prefs, font: FontFamily, onBack: () -> Unit, onIndex: () -> Unit) {
    val pagerState = rememberPagerState(
        initialPage = (startPage - 1).coerceIn(0, 603),
        pageCount = { 604 }
    )
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { prefs.saveLastPage(it + 1) }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar(
            title = "المصحف",
            onBack = onBack,
            actions = {
                TextButton(onClick = onIndex) { Text("الفهرس", color = Brand.Gold) }
                TextButton(onClick = { prefs.changeFontSize((prefs.fontSize - 2f).coerceAtLeast(18f)) }) {
                    Text("أ-", color = Brand.Gold, fontSize = 18.sp)
                }
                TextButton(onClick = { prefs.changeFontSize((prefs.fontSize + 2f).coerceAtMost(44f)) }) {
                    Text("أ+", color = Brand.Gold, fontSize = 18.sp)
                }
            }
        )
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) { idx -> MushafPage(idx + 1, prefs, font) }
    }
}

@Composable
fun MushafPage(page: Int, prefs: Prefs, font: FontFamily) {
    val entries = remember(page) { Quran.pageEntries(page) }
    val first = entries.firstOrNull()
    val firstAyah = first?.let { Quran.surahs[it.first - 1].ayahs[it.second - 1] }
    val surahName = first?.let { Quran.surahs[it.first - 1].name } ?: ""
    val parts = remember(page) {
        val out = ArrayList<Any>()
        var sb: AnnotatedString.Builder? = null
        for ((sn, an) in entries) {
            val s = Quran.surahs[sn - 1]
            if (an == 1) {
                sb?.let { out.add(it.toAnnotatedString()) }
                sb = null
                out.add(sn)
            }
            val cur = sb ?: AnnotatedString.Builder().also { sb = it }
            cur.append(s.ayahs[an - 1].text)
            cur.append(" ")
            cur.withStyle(SpanStyle(color = Brand.Gold, fontWeight = FontWeight.Bold)) {
                append("\uFD3F" + ArabicText.toArabicDigits(an) + "\uFD3E")
            }
            cur.append("  ")
        }
        sb?.let { out.add(it.toAnnotatedString()) }
        out
    }
    val size = prefs.fontSize * 0.9f
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "الجزء " + ArabicText.toArabicDigits(firstAyah?.juz ?: 0),
                color = Brand.Gold,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.weight(1f))
            Text(surahName, color = Brand.Gold, fontWeight = FontWeight.Bold)
        }
        HorizontalDivider()
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp)
        ) {
            for (p in parts) {
                if (p is Int) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, Brand.Gold, RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            Quran.surahs[p - 1].name,
                            fontFamily = font,
                            fontSize = (size + 2f).sp,
                            color = Brand.Gold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (p != 1 && p != 9) {
                        Text(
                            Quran.surahs[0].ayahs[0].text,
                            fontFamily = font,
                            fontSize = size.sp,
                            lineHeight = (size * 1.8f).sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                } else if (p is AnnotatedString) {
                    Text(
                        p,
                        fontFamily = font,
                        fontSize = size.sp,
                        lineHeight = (size * 1.8f).sp,
                        textAlign = TextAlign.Justify,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .border(1.dp, Brand.Gold, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            ) {
                val hz = MushafText.hizbLabel(firstAyah?.hizbQuarter ?: 0)
                Text(
                    (if (hz.isNotEmpty()) hz + "   |   " else "") + ArabicText.toArabicDigits(page),
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(2.dp))
    }
}
